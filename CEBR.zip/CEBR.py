#######################################################################################################################
###########---------Please use the POS2ABR program to generate the out file before running this code---------##########
#######################################################################################################################

from tabulate import tabulate
import re
import os

out_file_path = 'out'
space_group_number = None

try:
    with open(out_file_path, 'r', encoding='utf-8') as file:
        first_line = file.readline()
        space_group_number = first_line.split()[0]
        print("+------------------+")
        print(f"| Space group: {space_group_number} |")
        print("+------------------+")

        wyck_band_rep_mapping_p = {}
        wyck_band_rep_mapping_d = {}

        for line in file:
            parts = line.strip().split()
            for orbital_type in ['-p', '-d']:
                if len(parts) >= 2 and orbital_type in parts[1]:
                    site = None
                    for part in parts:
                        if '@' in part:
                            if part.endswith('('):
                                match = re.search(r'@([a-zA-Z0-9]+)', part)
                                if match:
                                    site = match.group(1)
                            else:
                                at_index = parts.index('@')
                                if at_index + 1 < len(parts):
                                    site = parts[at_index + 1].split('(')[0]
                            break
                    if site:
                        band_reps = []
                        for next_line in file:
                            if '@' in next_line:
                                break
                            next_parts = next_line.strip().split()
                            for part in next_parts:
                                clean_part = part.replace(';', '')
                                if any(char in clean_part for char in 'ABET'):
                                    if 'GM' in clean_part:
                                        split_parts = re.split('[+-]', clean_part)
                                        sub_band_reps = [sub_part for sub_part in split_parts if
                                                         any(char in sub_part for char in 'ABET')]
                                        for sub_band_rep in sub_band_reps:
                                            if sub_band_rep not in band_reps:
                                                band_reps.append(sub_band_rep)
                                    else:
                                        if clean_part not in band_reps:
                                            band_reps.append(clean_part)
                        if orbital_type == '-p':
                            if site not in wyck_band_rep_mapping_p:
                                wyck_band_rep_mapping_p[site] = []
                            wyck_band_rep_mapping_p[site].extend(band_reps)
                        else:
                            if site not in wyck_band_rep_mapping_d:
                                wyck_band_rep_mapping_d[site] = []
                            wyck_band_rep_mapping_d[site].extend(band_reps)

except FileNotFoundError:
    print(f"The {out_file_path} file was not found, exiting the program.")
    exit(1)

if not wyck_band_rep_mapping_p or not wyck_band_rep_mapping_d:
    print("Both p and d orbitals are not present, exiting the program.")
    exit(1)


def split_combined_band_rep(band_rep):
    return re.findall(r'[A-Z]?\d?[A-Z]?[gu]?\'*', band_rep)


specific_path = "./spacegroup"
dat_file_name = os.path.join(specific_path, f"{space_group_number}.dat")

try:
    with open(dat_file_name, 'r', encoding='utf-8') as dat_file:
        lines = dat_file.readlines()

        wyckoff_positions = set()
        for line in lines:
            if line.startswith('#') and not line.startswith('# ' + space_group_number):
                parts = line.strip().split()
                for part in parts:
                    if part != '#' and not part.startswith('#'):
                        wyckoff_positions.add(part)

        wyckoff_data = {}
        for wyck in wyckoff_positions:
            wyckoff_data[wyck] = {'irrep_line': None, 'g_line': None}

        for index, line in enumerate(lines):
            if line.startswith('#') and not line.startswith('# ' + space_group_number):
                parts = line.strip().split()
                for part in parts:
                    if part != '#' and not part.startswith('#'):
                        if index + 1 < len(lines):
                            wyckoff_data[part]['irrep_line'] = lines[index + 1].strip()
                        if index + 2 < len(lines):
                            wyckoff_data[part]['g_line'] = lines[index + 2].strip()

        results_p = []
        for wyck, band_reps in wyck_band_rep_mapping_p.items():
            if wyck in wyckoff_data and wyckoff_data[wyck]['irrep_line'] and wyckoff_data[wyck]['g_line']:
                target_irrep_line = wyckoff_data[wyck]['irrep_line']
                target_g_line = wyckoff_data[wyck]['g_line']

                band_rep_list = []
                g_list = []
                irrep_tokens = target_irrep_line.split()[1:]
                g_tokens = target_g_line.split()[1:]
                for i, irrep_token in enumerate(irrep_tokens):
                    sub_band_reps = split_combined_band_rep(irrep_token)
                    for sub_band_rep in sub_band_reps:
                        band_rep_list.append(sub_band_rep)
                        g_list.append(g_tokens[i])
                for band_rep in band_reps:
                    if band_rep in band_rep_list:
                        index = band_rep_list.index(band_rep)
                        g_value = g_list[index]
                        abrs = f"{wyck}@{band_rep}"
                        results_p.append([wyck, band_rep, abrs, g_value])

        results_d = []
        for wyck, band_reps in wyck_band_rep_mapping_d.items():
            if wyck in wyckoff_data and wyckoff_data[wyck]['irrep_line'] and wyckoff_data[wyck]['g_line']:
                target_irrep_line = wyckoff_data[wyck]['irrep_line']
                target_g_line = wyckoff_data[wyck]['g_line']

                band_rep_list = []
                g_list = []
                irrep_tokens = target_irrep_line.split()[1:]
                g_tokens = target_g_line.split()[1:]
                for i, irrep_token in enumerate(irrep_tokens):
                    sub_band_reps = split_combined_band_rep(irrep_token)
                    for sub_band_rep in sub_band_reps:
                        band_rep_list.append(sub_band_rep)
                        g_list.append(g_tokens[i])
                for band_rep in band_reps:
                    if band_rep in band_rep_list:
                        index = band_rep_list.index(band_rep)
                        g_value = g_list[index]
                        abrs = f"{wyck}@{band_rep}"
                        results_d.append([wyck, band_rep, abrs, g_value])

        print("\n************************************************************************************")
        print("p orbitals:")
        print(tabulate(results_p, headers=["Wyck.", "band-rep.", "ABRs", "BRs"], tablefmt="grid"))
        print("\nd orbitals:")
        print(tabulate(results_d, headers=["Wyck.", "band-rep.", "ABRs", "BRs"], tablefmt="grid"))
except FileNotFoundError:
    print(
        f"The {dat_file_name} file corresponding to space group {space_group_number} was not found, exiting the program.")
    exit(1)
except Exception as e:
    print(f"An unknown error occurred: {e}")


def split_g_value(g_value):
    return g_value.replace('⊕', ' ').split()


g_values_p = [split_g_value(result[3]) for result in results_p]
flat_g_values_p = {val for sublist in g_values_p for val in sublist}

g_values_d = [split_g_value(result[3]) for result in results_d]
flat_g_values_d = {val for sublist in g_values_d for val in sublist}

print("\nThe BRs of p orbitals :", flat_g_values_p)
print("The BRs of d orbitals :", flat_g_values_d)

has_common = bool(flat_g_values_p.intersection(flat_g_values_d))
if has_common:
    print("\nThe BRs of p orbitals and d orbitals maybe matching.")
else:
    print("\nThe BRs of p orbitals and d orbitals are mismatch.")
print("************************************************************************************")

